# Module 4 Assignment
# Kingsley Edionwe
# Learners ID: 157398

# Load necessary libraries
library(zip)
library(dplyr)
library(ggplot2)
library(tidyr)
# Data Preparation
unzip("C:/Users/kings/OneDrive/Desktop/Python/Module 4/netflix_data.zip", exdir = "C:/Users/kings/OneDrive/Desktop/Python/Module 4/Netflix_shows_movies")

# Load the dataset
netflix_data <- read.csv("C:/Users/kings/OneDrive/Desktop/Python/Module 4/Netflix_shows_movies/netflix_data.csv")

# Data Cleaning
netflix_data <- netflix_data %>%
  mutate(across(everything(), ~replace(., is.na(.), "Unknown")))

# Ensure 'rating' is numeric
netflix_data$rating <- as.numeric(as.character(netflix_data$rating))

# Data Exploration
summary(netflix_data)
str(netflix_data)

# Statistical Analysis
genre_count <- netflix_data %>%
  group_by(genre) %>%
  summarise(count = n()) %>%
  arrange(desc(count))

# Data Visualization
# Most watched genres
ggplot(genre_count, aes(x = reorder(genre, -count), y = count)) +
  geom_bar(stat = "identity", fill = "red") +
  labs(title = "Most Watched Genres", x = "Genre", y = "Count") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

